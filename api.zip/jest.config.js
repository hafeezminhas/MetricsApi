/**
 * Created by Hafeez Rehman on 03/03/2021.
 */
module.exports = {
    preset: 'ts-jest',
    testEnvironment: 'node',
};