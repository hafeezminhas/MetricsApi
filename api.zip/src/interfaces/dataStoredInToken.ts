interface TokenPayload {
  _id: string;
  fullName: string;
  email: string;
  phone: string;
  role: string;
}

export default TokenPayload;
