class PlantPhaseHistory {
  public phase: number;
  public start: Date;
  public end?: Date;
}

export { PlantPhaseHistory }