export const phaseHistoryList = ['Seedling', 'Clone', 'Vegetative', 'Flowering', 'Mother'];

export enum PlantPhaseHistoryItem {
  Seedling,
  Clone,
  Vegetative,
  Flowering,
  Mother,
}
